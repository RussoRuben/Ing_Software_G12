var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito =
[
    [ "Prestito", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#aa77dd543699034c401a0e856d23e9b77", null ],
    [ "getCodice", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#aa46a32cc06600a0bd5e342970b031bd6", null ],
    [ "getDataFine", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#aa6ee5e61fed9501cc7d239d9dc013c3e", null ],
    [ "getDataInizio", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#a00fb3af93e942237c1b6c4fc9cd9a291", null ],
    [ "getLibro", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#acddb58ab344aba78c53c0be78f68686b", null ],
    [ "getLibroString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#ae956f2b6f0239e3e10d69f896ec514ca", null ],
    [ "getStudente", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#a506e7b2e68f51c03dd2c6a3b0e60528f", null ],
    [ "getStudenteString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#a3bd845a9258023e04340b99ef46a6cff", null ],
    [ "setDataFine", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#ac9ecd883a08a545d62f2e2f418d18a69", null ]
];