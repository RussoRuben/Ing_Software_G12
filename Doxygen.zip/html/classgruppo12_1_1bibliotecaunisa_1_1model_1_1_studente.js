var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente =
[
    [ "Studente", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a4c126d15dfe2053e94899b0c2c78b7d2", null ],
    [ "aggiungiListaPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a70db9b5266a2180cffd25542129db72b", null ],
    [ "getCognome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a01d0d92faf5b95d7918b8733c2592127", null ],
    [ "getEmail", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#ab3220a3e39cd2a67d07374da1f89355c", null ],
    [ "getListaPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#af66d8dbbba77d5de22ee00cffcca97d3", null ],
    [ "getListaPrestitiString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#afa996e160fac938c0b18706454137e2d", null ],
    [ "getMatricola", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a79f3c9fbc579e53e02fd15e1deaa748a", null ],
    [ "getNome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#ac3c7eee6fbe550e41fa7cd020af8ef10", null ],
    [ "rimuoviListaPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#adc7be2270c708b2d631b6f2477ca6b26", null ],
    [ "setCognome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a8d5c26e4487724e1dca2ec63d98fed40", null ],
    [ "setEmail", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#afe8dca6142cd9b710f1f00f34d0add84", null ],
    [ "setListaPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a6121b4663730a9427a7ceaa872202780", null ],
    [ "setMatricola", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#afa8b81554e4ca3b25d47e0e259064a43", null ],
    [ "setNome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#aa80a576f91e0bbe386520e8ee16948bf", null ],
    [ "toString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a6e7c43f6c850a35796a7256163eff891", null ]
];