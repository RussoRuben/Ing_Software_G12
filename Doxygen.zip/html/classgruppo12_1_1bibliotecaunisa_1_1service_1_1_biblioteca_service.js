var classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service =
[
    [ "BibliotecaService", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#acb8966760ebd5fc66a09084288fdf00d", null ],
    [ "aggiungiLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a26a014d48586ee41306023f94de61f9c", null ],
    [ "aggiungiPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a1716241249574ba85ac77e1ba8fceb9f", null ],
    [ "aggiungiStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a40faa6eaed1ecccaa2aef7a9739fae2e", null ],
    [ "getLibri", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a67f794bf8b83bb275e531e6911bf7de7", null ],
    [ "getPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#acbf235632adf9af48c635082e3b58877", null ],
    [ "getPrestitiArchiviati", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a70f7bd088db10164ae5dd6d2041b4671", null ],
    [ "getStudenti", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a32a95fc62a591d26db94cfbefe049b09", null ],
    [ "modificaLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#af92d586ddcfd752b10366e300f9f741a", null ],
    [ "modificaStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a6e65a3a3b24dc37e5264461fbf8ec41d", null ],
    [ "restituisciPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#af63cc14cb982d0946a2f843d2158b6e5", null ],
    [ "rimuoviLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#aa061378750aee8f248a7aa07935b3ca7", null ],
    [ "rimuoviStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#abb8b6ec4147e085e9aa46f3ad1a8c0d9", null ],
    [ "trovaLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#afc00e139d2e312a4b4c99dfba32ce313", null ],
    [ "trovaPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#ab952f58c82f5f2f82dce0e881774ffe8", null ],
    [ "trovaPrestitoArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#adf36d6170b51dddbe86eb5217ff0b612", null ],
    [ "trovaStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#aabdef6e8781a1286b62e38503aa541eb", null ]
];