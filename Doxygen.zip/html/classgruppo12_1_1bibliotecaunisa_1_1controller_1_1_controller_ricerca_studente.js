var classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente =
[
    [ "initialize", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html#ab5ff724d84fd8ba79311101f92aa057c", null ],
    [ "initService", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html#aa7e748907c1805a63bc0c76dd1ce75e5", null ],
    [ "setControllerChiamante", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html#ad5a8a9821ab0ba5e66128d1a88e35acc", null ]
];