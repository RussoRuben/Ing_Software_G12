var classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro =
[
    [ "setLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro.html#afecd3024cad09b055d6b23292ade401f", null ]
];