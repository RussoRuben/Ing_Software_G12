var classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente =
[
    [ "setStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente.html#a5fb4c9214c78eea51edd9155a374d086", null ]
];