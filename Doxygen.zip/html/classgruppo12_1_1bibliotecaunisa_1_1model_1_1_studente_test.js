var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test =
[
    [ "testAggiungiListaPrestiti_Failure", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#ae1dcdaebe33394a922cbdf1b0807f99a", null ],
    [ "testAggiungiListaPrestiti_Success", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a54e1db061c0c9a13a44870b5cea12890", null ],
    [ "testCostruttore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a3d472014ef7006ad360d5ad179975875", null ],
    [ "testGetCognome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a5a6879123ade37ea9438e26049b7c1c6", null ],
    [ "testGetEmail", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#aa878f7c5b32ef66766fa11a03498a71c", null ],
    [ "testGetListaPrestitiString_Empty", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a9d137d6e0d417f43c4cc028da87c22b2", null ],
    [ "testGetListaPrestitiString_MoreItems", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a7b00ef17477c5b0cea84636f86af4293", null ],
    [ "testGetListaPrestitiString_SingleItem", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a1977098466e92b68fb40db087c82b4cc", null ],
    [ "testGetMatricola", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#ae35fc5bd372e09e3a9eb435382d63d1a", null ],
    [ "testGetNome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a2853a5aab2bca3d8ab796eb344b9e836", null ],
    [ "testListaPrestiti_Empty", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a41bf20c88b3b639013953f52cb942e6c", null ],
    [ "testRimuoviListaPrestiti_Success", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a62d172f63f67c1f1fe08950aa63f1276", null ],
    [ "testSetCognome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a3428d5df3ddabd9f0191f59a1ea57120", null ],
    [ "testSetEmail", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a70bdb56d59192b09a8b2e242ec2cd35a", null ],
    [ "testSetListaPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#ad3c5d6b6b1a3e58ba15a2422dbb39074", null ],
    [ "testSetMatricola", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a60ee6ef9a6b3100a0ec79e32597cd6f4", null ],
    [ "testSetNome", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a467cc2398e8ad1a86cd06c1136035912", null ],
    [ "testToString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html#a2c401d3c2a36bf1483157bf03589b216", null ]
];