var classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository =
[
    [ "add", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#a0580c2a47e21a1059a2ec3d8c6b56e5d", null ],
    [ "findByKey", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#a6480bfbf4e69ee702d11fb8363cb9616", null ],
    [ "getAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#ab06046961c41cabf91f87e8ff36c579b", null ],
    [ "remove", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#a331c2bcb34e8f65a13b52d706e50f967", null ],
    [ "replaceAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#ae4c37a8e329d2d27d3f467c158fdc928", null ]
];