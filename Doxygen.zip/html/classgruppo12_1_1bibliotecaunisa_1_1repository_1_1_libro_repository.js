var classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository =
[
    [ "add", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#a736e98510571776b526d0840291d2b1d", null ],
    [ "findByKey", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#a1daf20a190bd2118c620ae2696c5f4d9", null ],
    [ "getAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#af784501ae15d65720473f57e86369334", null ],
    [ "remove", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#a2d7a28141f91ddae952b8d232c78cf4f", null ],
    [ "replaceAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#aed3e615ae2d6df5623b92baa435c21c5", null ]
];