var classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test =
[
    [ "testAggiungiLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#acbafc55399771f421a3658de39913adf", null ],
    [ "testAggiungiPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#ac264d3a6c6b0a3fe925c833471fd4472", null ],
    [ "testAggiungiStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a532ae53759d9ba4250f62e8854436ff7", null ],
    [ "testGetLibri", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a980236640252d3ab2b4c5ac1a07dfb9a", null ],
    [ "testGetPrestiti", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a0250bac43d518a683da9298abdda6be1", null ],
    [ "testGetPrestitiArchiviati", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a9c4ad87d40a23f4d1cd5e2a401ce1e76", null ],
    [ "testGetStudenti", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#af578a4b2c843694928b7c91c1475c8b9", null ],
    [ "testModificaLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a009aaa9c61f8c69c6b884d6d8111309d", null ],
    [ "testModificaStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#ae1cf3858af0e68752688f502f1a2fb35", null ],
    [ "testRestituisciPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#ad407d6f1881a31dbb2a4d87cca4a4649", null ],
    [ "testRimuoviLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a881e22c53735acc455714559dc12147f", null ],
    [ "testRimuoviStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a2c4243a3e87aef712e2064dc65710644", null ],
    [ "testTrovaLibro", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a64587f1c1b59153fbd5ff4581a3f0ab2", null ],
    [ "testTrovaPrestito", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#ac1d4469ef13791d8e03846ccc61e0631", null ],
    [ "testTrovaPrestitoArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a508c23cfd52e4b8088ce2c6481fd824d", null ],
    [ "testTrovaStudente", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html#a159fe93c011c89159427c64ec11f1e72", null ]
];