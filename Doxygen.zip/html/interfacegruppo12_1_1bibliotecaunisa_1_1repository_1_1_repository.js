var interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository =
[
    [ "add", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#a16124993cbe0936ce08b5f0e6352871e", null ],
    [ "findByKey", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#afc3b1cbad9548d0358d5edb1450d82c5", null ],
    [ "getAll", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#a1d1939bbf48ac0a2ffae0945ba6443da", null ],
    [ "remove", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#a712d2031e659e53eff010520c0e0940c", null ],
    [ "replaceAll", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#a6324ddc1fd49150e4704bc16fb16f11d", null ]
];