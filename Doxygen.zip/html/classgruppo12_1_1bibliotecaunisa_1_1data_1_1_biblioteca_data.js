var classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data =
[
    [ "BibliotecaData", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#ab2731b53efc8fabbff33eb7943a56b63", null ],
    [ "caricaStato", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a01870e04d83a6c94c4887bf9c27cd535", null ],
    [ "caricaStato", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a3f68f354fd08bf928b8255b8ce10414c", null ],
    [ "getLibroRepo", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a77c91702068308073d35ac2736a11ec6", null ],
    [ "getPrestitoRepo", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a0998f1b5991d17f4163050e81d4cbeac", null ],
    [ "getStudenteRepo", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#ab3913c3c68ac6080b605af682d4bc4be", null ],
    [ "salvaStato", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#af1cde44d9f7a9fb81516dad04dc72265", null ],
    [ "salvaStato", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a3444a774b608e83d76229c05ce148dae", null ]
];