var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro =
[
    [ "Libro", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a6e6de4824cc10269afefc2e7791017d5", null ],
    [ "getAnno", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a414e146a122fb3921d51537cbce72a55", null ],
    [ "getAutori", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#ad5e98143510e7520b43687401efdf29f", null ],
    [ "getAutoriString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a70e70c9da25107f83ee8ed1b62345d62", null ],
    [ "getCodice", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a74d34960aa9db532721ff96a4a2d47d4", null ],
    [ "getCopieDisponibili", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#aa3b0385d8c5805c25f81727bd68d062c", null ],
    [ "getEditore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a2d56c76703fcef58f297967b214e657b", null ],
    [ "getNumeroEdizione", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a6092e98cb229e13ade46218c79e0bf73", null ],
    [ "getTitolo", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a3f309e025b2004233470582b951fa9d0", null ],
    [ "setAnno", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a9962aff9043701cf89c3984fd36e5f3d", null ],
    [ "setAutori", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a154bfe6294cea0c50f6e1374b560f220", null ],
    [ "setCodice", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a6260afc3f0881f588584386a006f9980", null ],
    [ "setEditore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#af0bd85d7b00eefb7d9b5db93497f8f3b", null ],
    [ "setNumeroEdizione", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a9f8106431b06eb09cffb3c89aeda4d02", null ],
    [ "setTitolo", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a463f8f59cf44142f96230e055d851fa9", null ],
    [ "toString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#aaaa112a2208cd7cb7924ba07aa07e46e", null ]
];