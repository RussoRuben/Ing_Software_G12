var hierarchy =
[
    [ "Application", null, [
      [ "gruppo12.bibliotecaunisa.App", "classgruppo12_1_1bibliotecaunisa_1_1_app.html", null ]
    ] ],
    [ "gruppo12.bibliotecaunisa.data.BibliotecaData", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html", null ],
    [ "gruppo12.bibliotecaunisa.service.BibliotecaService", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html", null ],
    [ "gruppo12.bibliotecaunisa.service.BibliotecaServiceTest", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html", null ],
    [ "gruppo12.bibliotecaunisa.controller.ControllerService", "interfacegruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_service.html", [
      [ "gruppo12.bibliotecaunisa.controller.ControllerAggiungiLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_libro.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerAggiungiStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_studente.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerPrestito", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerPrincipale", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_principale.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerRestituzione", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_restituzione.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerRicercaLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerRicercaStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerVisualizzaLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerVisualizzaPrestitoArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_prestito_archiviato.html", null ],
      [ "gruppo12.bibliotecaunisa.controller.ControllerVisualizzaStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente.html", null ]
    ] ],
    [ "gruppo12.bibliotecaunisa.repository.LibroRepositoryTest", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository_test.html", null ],
    [ "gruppo12.bibliotecaunisa.model.LibroTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html", null ],
    [ "gruppo12.bibliotecaunisa.model.PrestitoTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html", null ],
    [ "gruppo12.bibliotecaunisa.repository.Repository&lt; K, T &gt;", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html", null ],
    [ "gruppo12.bibliotecaunisa.repository.Repository&lt; Long, Prestito &gt;", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html", [
      [ "gruppo12.bibliotecaunisa.repository.PrestitoRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html", null ]
    ] ],
    [ "gruppo12.bibliotecaunisa.repository.Repository&lt; String, Libro &gt;", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html", [
      [ "gruppo12.bibliotecaunisa.repository.LibroRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html", null ]
    ] ],
    [ "gruppo12.bibliotecaunisa.repository.Repository&lt; String, Studente &gt;", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html", [
      [ "gruppo12.bibliotecaunisa.repository.StudenteRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html", null ]
    ] ],
    [ "Serializable", null, [
      [ "gruppo12.bibliotecaunisa.model.Libro", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html", null ],
      [ "gruppo12.bibliotecaunisa.model.Prestito", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html", null ],
      [ "gruppo12.bibliotecaunisa.model.Studente", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html", null ]
    ] ],
    [ "gruppo12.bibliotecaunisa.model.StudenteTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html", null ]
];