var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test =
[
    [ "testCostruttore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a81fc3e12aefaf8d32efef82248655d97", null ],
    [ "testGetAnno", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a6b515e89bf3a222bf0d760eeabf64b1f", null ],
    [ "testGetAutoriString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#aa6ec3a763f327da98a9ec554a5752b40", null ],
    [ "testGetCodice", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a9dcd43c22d7a3af73700acc1cdce2126", null ],
    [ "testGetCopieDisponibili", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#aecabf792a7cb3554c8293b246cde2f71", null ],
    [ "testGetEditore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#ab35534c39091f39175d164eecbcdf409", null ],
    [ "testGetNumeroEdizione", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#ab9efa96568f06eed66b9abeabea22657", null ],
    [ "testGetTitolo", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#acaba18dbac77e841a1066ed5b3ba2c4c", null ],
    [ "testSetAnno", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#ae81779f0e6a47e09cc0c8de75efd59e4", null ],
    [ "testSetAutori", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a25b3a9e10a1c147f514f3a3d63cf3cf2", null ],
    [ "testSetCodice", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a5fbbea2401c553960075ca16cbab976b", null ],
    [ "testSetCopieDisponibili", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a9a3a38e72a1f3868c0ce937d792c65db", null ],
    [ "testSetEditore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#aba1b98f08d96004275503c5e565661f9", null ],
    [ "testSetNumeroEdizione", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a9fcfd96cd17d9ec1c535dbebfea2cc11", null ],
    [ "testSetTitolo", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a7512e0bfa45700fcc7483f7ee310bd15", null ],
    [ "testToString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html#a6220968eb3c67c992c7303873edc732e", null ]
];