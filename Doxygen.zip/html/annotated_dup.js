var annotated_dup =
[
    [ "gruppo12", null, [
      [ "bibliotecaunisa", null, [
        [ "controller", null, [
          [ "ControllerAggiungiLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_libro.html", null ],
          [ "ControllerAggiungiStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_studente.html", null ],
          [ "ControllerPrestito", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito" ],
          [ "ControllerPrincipale", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_principale.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_principale" ],
          [ "ControllerRestituzione", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_restituzione.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_restituzione" ],
          [ "ControllerRicercaLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro" ],
          [ "ControllerRicercaStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente" ],
          [ "ControllerService", "interfacegruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_service.html", null ],
          [ "ControllerVisualizzaLibro", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro" ],
          [ "ControllerVisualizzaPrestitoArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_prestito_archiviato.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_prestito_archiviato" ],
          [ "ControllerVisualizzaStudente", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente.html", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente" ]
        ] ],
        [ "data", null, [
          [ "BibliotecaData", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html", "classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data" ]
        ] ],
        [ "model", null, [
          [ "Libro", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro" ],
          [ "Prestito", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito" ],
          [ "Studente", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente" ],
          [ "LibroTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test" ],
          [ "PrestitoTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test" ],
          [ "StudenteTest", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test" ]
        ] ],
        [ "repository", null, [
          [ "LibroRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository" ],
          [ "PrestitoRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository" ],
          [ "Repository", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html", "interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository" ],
          [ "StudenteRepository", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository" ],
          [ "LibroRepositoryTest", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository_test.html", null ]
        ] ],
        [ "service", null, [
          [ "BibliotecaService", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service" ],
          [ "BibliotecaServiceTest", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html", "classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test" ]
        ] ],
        [ "App", "classgruppo12_1_1bibliotecaunisa_1_1_app.html", null ]
      ] ]
    ] ]
];