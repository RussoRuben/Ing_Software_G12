var classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro =
[
    [ "initialize", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html#af5b66ce1a77c95d592a01142a46c172f", null ],
    [ "initService", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html#a0d6623bfd0781d0af428bde41e05c205", null ],
    [ "setControllerChiamante", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html#ae13f0e6bfb2735a515b2bd76a6a92616", null ]
];