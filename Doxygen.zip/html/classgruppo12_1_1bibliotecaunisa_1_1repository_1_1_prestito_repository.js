var classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository =
[
    [ "add", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#aed575d4cd34b8b349bf08e9c02d86859", null ],
    [ "addArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a10a21e46dbd3196c5384ccd2e321ac93", null ],
    [ "findArchiviatoByKey", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a30025ad92156f7489b588c1898697644", null ],
    [ "findByKey", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a970dea8420c3ca075e28c54952ef1785", null ],
    [ "getAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a5c939369e36a7428b0f42af495891edc", null ],
    [ "getAllArchiviati", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a2f6cc27db67fa054160c867d93a76a40", null ],
    [ "remove", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a80bd2410a70ffc49fc93a00c3b6a938a", null ],
    [ "removeArchiviato", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a8af00da57841e5973e469c0bcb4caa6a", null ],
    [ "replaceAll", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a13bf75e79b541a4f6db6271653b478c8", null ],
    [ "replaceAllArchiviati", "classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#aa919924502b9fe71650815e43468bec2", null ]
];