var classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito =
[
    [ "getRoot", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html#a5b9a5df8047b897fdcc29a2e20cfcc35", null ],
    [ "setLibroSelezionato", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html#a45d8cde1997b995c82bdd2a6a7992a2d", null ],
    [ "setRoot", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html#a419d29d546f61e45d9e99e1fbcf8946c", null ],
    [ "setStudenteSelezionato", "classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html#a35dc851f36b1c63e45dee44bc9019e24", null ]
];