var classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test =
[
    [ "testCostruttore", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#ac23160a8b74e4ded30baa1a21ee48ccb", null ],
    [ "testGetLibroString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#a7112a95bd330ad8e2fdfbdf7f64c7755", null ],
    [ "testGetSetNum", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#a19806d026347015d1bad91b4b15f1a32", null ],
    [ "testGetStudente", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#a9c2e2296186aef6f6905490da938f8c4", null ],
    [ "testGetStudenteString", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#ab05cd43676570828cc5b1e8f7e2afc14", null ],
    [ "testSetDataFine", "classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html#a30d8ae09bfedd899eaf847e84f56b46c", null ]
];