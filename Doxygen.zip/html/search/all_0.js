var searchData=
[
  ['add_0',['add',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html#a736e98510571776b526d0840291d2b1d',1,'gruppo12.bibliotecaunisa.repository.LibroRepository.add()'],['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#aed575d4cd34b8b349bf08e9c02d86859',1,'gruppo12.bibliotecaunisa.repository.PrestitoRepository.add()'],['../interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html#a16124993cbe0936ce08b5f0e6352871e',1,'gruppo12.bibliotecaunisa.repository.Repository.add()'],['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html#a0580c2a47e21a1059a2ec3d8c6b56e5d',1,'gruppo12.bibliotecaunisa.repository.StudenteRepository.add()']]],
  ['addarchiviato_1',['addArchiviato',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html#a10a21e46dbd3196c5384ccd2e321ac93',1,'gruppo12::bibliotecaunisa::repository::PrestitoRepository']]],
  ['aggiungilibro_2',['aggiungiLibro',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a26a014d48586ee41306023f94de61f9c',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]],
  ['aggiungilistaprestiti_3',['aggiungiListaPrestiti',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html#a70db9b5266a2180cffd25542129db72b',1,'gruppo12::bibliotecaunisa::model::Studente']]],
  ['aggiungiprestito_4',['aggiungiPrestito',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a1716241249574ba85ac77e1ba8fceb9f',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]],
  ['aggiungistudente_5',['aggiungiStudente',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a40faa6eaed1ecccaa2aef7a9739fae2e',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]],
  ['app_6',['App',['../classgruppo12_1_1bibliotecaunisa_1_1_app.html',1,'gruppo12::bibliotecaunisa']]]
];
