var searchData=
[
  ['prestito_0',['Prestito',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html',1,'gruppo12::bibliotecaunisa::model']]],
  ['prestitorepository_1',['PrestitoRepository',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_prestito_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['prestitotest_2',['PrestitoTest',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito_test.html',1,'gruppo12::bibliotecaunisa::model']]]
];
