var searchData=
[
  ['bibliotecadata_0',['BibliotecaData',['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#ab2731b53efc8fabbff33eb7943a56b63',1,'gruppo12::bibliotecaunisa::data::BibliotecaData']]],
  ['bibliotecaservice_1',['BibliotecaService',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#acb8966760ebd5fc66a09084288fdf00d',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]]
];
