var searchData=
[
  ['prestito_0',['Prestito',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_prestito.html#aa77dd543699034c401a0e856d23e9b77',1,'gruppo12::bibliotecaunisa::model::Prestito']]]
];
