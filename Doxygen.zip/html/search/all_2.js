var searchData=
[
  ['caricastato_0',['caricaStato',['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a01870e04d83a6c94c4887bf9c27cd535',1,'gruppo12.bibliotecaunisa.data.BibliotecaData.caricaStato()'],['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a3f68f354fd08bf928b8255b8ce10414c',1,'gruppo12.bibliotecaunisa.data.BibliotecaData.caricaStato(String filePath)']]],
  ['controlleraggiungilibro_1',['ControllerAggiungiLibro',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_libro.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controlleraggiungistudente_2',['ControllerAggiungiStudente',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_aggiungi_studente.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerprestito_3',['ControllerPrestito',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_prestito.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerprincipale_4',['ControllerPrincipale',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_principale.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerrestituzione_5',['ControllerRestituzione',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_restituzione.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerricercalibro_6',['ControllerRicercaLibro',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerricercastudente_7',['ControllerRicercaStudente',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllerservice_8',['ControllerService',['../interfacegruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_service.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllervisualizzalibro_9',['ControllerVisualizzaLibro',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_libro.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllervisualizzaprestitoarchiviato_10',['ControllerVisualizzaPrestitoArchiviato',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_prestito_archiviato.html',1,'gruppo12::bibliotecaunisa::controller']]],
  ['controllervisualizzastudente_11',['ControllerVisualizzaStudente',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_visualizza_studente.html',1,'gruppo12::bibliotecaunisa::controller']]]
];
