var searchData=
[
  ['bibliotecadata_0',['BibliotecaData',['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html',1,'gruppo12::bibliotecaunisa::data']]],
  ['bibliotecaservice_1',['BibliotecaService',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html',1,'gruppo12::bibliotecaunisa::service']]],
  ['bibliotecaservicetest_2',['BibliotecaServiceTest',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service_test.html',1,'gruppo12::bibliotecaunisa::service']]]
];
