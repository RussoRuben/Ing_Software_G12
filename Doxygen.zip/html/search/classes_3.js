var searchData=
[
  ['libro_0',['Libro',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html',1,'gruppo12::bibliotecaunisa::model']]],
  ['librorepository_1',['LibroRepository',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['librorepositorytest_2',['LibroRepositoryTest',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_libro_repository_test.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['librotest_3',['LibroTest',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro_test.html',1,'gruppo12::bibliotecaunisa::model']]]
];
