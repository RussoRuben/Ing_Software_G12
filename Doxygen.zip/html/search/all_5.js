var searchData=
[
  ['initialize_0',['initialize',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html#af5b66ce1a77c95d592a01142a46c172f',1,'gruppo12.bibliotecaunisa.controller.ControllerRicercaLibro.initialize()'],['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html#ab5ff724d84fd8ba79311101f92aa057c',1,'gruppo12.bibliotecaunisa.controller.ControllerRicercaStudente.initialize()']]],
  ['initservice_1',['initService',['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_libro.html#a0d6623bfd0781d0af428bde41e05c205',1,'gruppo12.bibliotecaunisa.controller.ControllerRicercaLibro.initService()'],['../classgruppo12_1_1bibliotecaunisa_1_1controller_1_1_controller_ricerca_studente.html#aa7e748907c1805a63bc0c76dd1ce75e5',1,'gruppo12.bibliotecaunisa.controller.ControllerRicercaStudente.initService()']]]
];
