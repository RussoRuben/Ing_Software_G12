var searchData=
[
  ['studente_0',['Studente',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente.html',1,'gruppo12::bibliotecaunisa::model']]],
  ['studenterepository_1',['StudenteRepository',['../classgruppo12_1_1bibliotecaunisa_1_1repository_1_1_studente_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['studentetest_2',['StudenteTest',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_studente_test.html',1,'gruppo12::bibliotecaunisa::model']]]
];
