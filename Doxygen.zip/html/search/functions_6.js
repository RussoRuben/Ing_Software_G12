var searchData=
[
  ['libro_0',['Libro',['../classgruppo12_1_1bibliotecaunisa_1_1model_1_1_libro.html#a6e6de4824cc10269afefc2e7791017d5',1,'gruppo12::bibliotecaunisa::model::Libro']]]
];
