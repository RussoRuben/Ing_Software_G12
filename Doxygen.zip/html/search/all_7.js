var searchData=
[
  ['modificalibro_0',['modificaLibro',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#af92d586ddcfd752b10366e300f9f741a',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]],
  ['modificastudente_1',['modificaStudente',['../classgruppo12_1_1bibliotecaunisa_1_1service_1_1_biblioteca_service.html#a6e65a3a3b24dc37e5264461fbf8ec41d',1,'gruppo12::bibliotecaunisa::service::BibliotecaService']]]
];
