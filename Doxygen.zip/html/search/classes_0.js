var searchData=
[
  ['app_0',['App',['../classgruppo12_1_1bibliotecaunisa_1_1_app.html',1,'gruppo12::bibliotecaunisa']]]
];
