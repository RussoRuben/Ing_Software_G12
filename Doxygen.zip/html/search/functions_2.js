var searchData=
[
  ['caricastato_0',['caricaStato',['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a01870e04d83a6c94c4887bf9c27cd535',1,'gruppo12.bibliotecaunisa.data.BibliotecaData.caricaStato()'],['../classgruppo12_1_1bibliotecaunisa_1_1data_1_1_biblioteca_data.html#a3f68f354fd08bf928b8255b8ce10414c',1,'gruppo12.bibliotecaunisa.data.BibliotecaData.caricaStato(String filePath)']]]
];
