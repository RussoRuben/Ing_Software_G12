var searchData=
[
  ['repository_0',['Repository',['../interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['repository_3c_20long_2c_20prestito_20_3e_1',['Repository&lt; Long, Prestito &gt;',['../interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['repository_3c_20string_2c_20libro_20_3e_2',['Repository&lt; String, Libro &gt;',['../interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html',1,'gruppo12::bibliotecaunisa::repository']]],
  ['repository_3c_20string_2c_20studente_20_3e_3',['Repository&lt; String, Studente &gt;',['../interfacegruppo12_1_1bibliotecaunisa_1_1repository_1_1_repository.html',1,'gruppo12::bibliotecaunisa::repository']]]
];
